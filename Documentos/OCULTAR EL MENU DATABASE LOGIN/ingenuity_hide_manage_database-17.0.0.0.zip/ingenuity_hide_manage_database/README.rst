========================
Ingenuity Hide Manage Database and Powered by Options
========================

This Module will allow to hide the Manage Database and Powered By options from the Odoo Login page.
By using this module you can hide secure your Database Information from public users. Also you can able to hide the Powered By Link from the login page.


Odoo Version
=============
Odoo 17 Community Edition


Release Notes
=============

[17.0.0.0] :  Add Module


Installation
============

To install this module, you need to: 'Web'

Download the module and add it to your Odoo addons folder. Afterward, log on to
your Odoo server and go to the Apps menu. Trigger the debug mode and update the
list by clicking on the "Update Apps List" link. Now install the module by
clicking on the install button.

Upgrade
=======

To upgrade this module, you need to:

Download the module and add it to your Odoo addons folder. Restart the server
and log on to your Odoo server. Select the Apps menu and upgrade the module by
clicking on the upgrade button.


Configuration
=============

There is Nothing to Configure


Credits
=======

Contributors
------------

* Ingenuity Info <contact@ingenuityinfo.in>


Author & Maintainer
-------------------

This module is maintained by the Ingenuity Info
